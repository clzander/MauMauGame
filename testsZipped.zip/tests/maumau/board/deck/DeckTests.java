package maumau.board.deck;

import maumau.cards.Card;
import org.testng.Assert;
import org.testng.annotations.Test;

public class DeckTests {

    /**
     *
     * @throws EmptyDeckException shouldn't be thrown
     */
    @Test
    public void drawTest() throws EmptyDeckException {
        DeckBackdoor deck = new MauMauDeck();

        final int LIST_LENGTH_DIFFERENCE = 1;
        final int TOP_CARD_INDEX = deck.getDeck().size() - LIST_LENGTH_DIFFERENCE;
        Card topCard = deck.getDeck().get(TOP_CARD_INDEX);

        Card drawnCard = deck.drawCard();

        Assert.assertEquals(topCard.getColor(), drawnCard.getColor());
        Assert.assertEquals(topCard.getType(), drawnCard.getType());
    }

    @Test
    public void exceptionThrownTest() {
        DeckBackdoor deck = new MauMauDeck();
        //size needs to be stored, because it's constantly changing in the for loop
        final int deckSize = deck.getDeck().size();

        for (int i = 0; i < deckSize; i++) {
            try {
                deck.drawCard();
            } catch (EmptyDeckException e) {
                //shouldn't end here
                //check test or implementation again
                System.out.println("Deck was already empty?");
                Assert.fail();
            }
        }
        Assert.assertThrows(EmptyDeckException.class, deck::drawCard);
    }
}
