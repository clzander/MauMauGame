package maumau.player;

import maumau.board.Board;
import maumau.board.MauMauBoard;
import maumau.board.ProvokedEmptyDeckException;
import maumau.board.deck.Deck;
import maumau.board.deck.MauMauDeck;
import maumau.cards.Card;
import maumau.cards.CardColor;
import maumau.cards.CardType;
import maumau.cards.MauMauCard;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

public class UsageTests {

    @Test
    public void notPlayersTurnExceptionTest() {
        Player alice = new MauMauPlayer("Alice", 1, 1);
        Assert.assertThrows(NotPlayersTurnException.class, alice::drawCard);
    }

    @Test
    public void playerHasNoSuchCardException() {
        final Card aliceCard = new MauMauCard(CardColor.CLUBS, CardType.ACE);
        final Card notAliceCard = new MauMauCard(CardColor.HEART, CardType.TEN);

        List<Card> aliceHandCards = new ArrayList<>();
        aliceHandCards.add(aliceCard);
        Player alice = new MauMauPlayer("Alice",aliceHandCards ,0, 1);
        Assert.assertThrows(PlayerHasNoSuchCardException.class, () -> alice.playCard(notAliceCard));
    }

    @Test
    public void playSimpleGoodGame() throws PlayerHasNoSuchCardException, NotPlayersTurnException, PlayerViolatesGameRulesException {
        //define everything separately to have "full control"
        List<Card> deckList = setupDeckSimpleGoodGame();
        Deck deck = new MauMauDeck(deckList);
        Board board = new MauMauBoard(deck);

        List<Card> aliceHand = new ArrayList<>();
        //alice start hand cards
        aliceHand.add(new MauMauCard(CardColor.CLUBS, CardType.TWO));
        aliceHand.add(new MauMauCard(CardColor.CLUBS, CardType.THREE));
        aliceHand.add(new MauMauCard(CardColor.CLUBS, CardType.FOUR));
        aliceHand.add(new MauMauCard(CardColor.CLUBS, CardType.FIVE));
        aliceHand.add(new MauMauCard(CardColor.CLUBS, CardType.SIX));
        aliceHand.add(new MauMauCard(CardColor.CLUBS, CardType.SEVEN));


        List<Card> bobHand = new ArrayList<>();
        //bob start hand cards
        bobHand.add(new MauMauCard(CardColor.CLUBS, CardType.NINE));
        bobHand.add(new MauMauCard(CardColor.CLUBS, CardType.TEN));
        bobHand.add(new MauMauCard(CardColor.CLUBS, CardType.JACK));
        bobHand.add(new MauMauCard(CardColor.CLUBS, CardType.QUEEN));
        bobHand.add(new MauMauCard(CardColor.CLUBS, CardType.KING));
        bobHand.add(new MauMauCard(CardColor.CLUBS, CardType.ACE));


        PlayerBackdoor alice = new MauMauPlayer("Alice", aliceHand, 0,1, board);
        PlayerBackdoor bob = new MauMauPlayer("Bob", bobHand, 1, 1, board);

        Assert.assertFalse(alice.playCard(new MauMauCard(CardColor.CLUBS, CardType.TWO)));
        this.updatePlayerTurnIndex(alice, bob);

        Assert.assertFalse(bob.playCard(new MauMauCard(CardColor.CLUBS, CardType.NINE)));
        this.updatePlayerTurnIndex(alice, bob);

        Assert.assertFalse(alice.playCard(new MauMauCard(CardColor.CLUBS, CardType.THREE)));
        this.updatePlayerTurnIndex(alice, bob);

        Assert.assertFalse(bob.playCard(new MauMauCard(CardColor.CLUBS, CardType.TEN)));
        this.updatePlayerTurnIndex(alice, bob);

        Assert.assertFalse(alice.playCard(new MauMauCard(CardColor.CLUBS, CardType.FOUR)));
        this.updatePlayerTurnIndex(alice, bob);

        Assert.assertFalse(bob.playCard(new MauMauCard(CardColor.CLUBS, CardType.JACK)));
        this.updatePlayerTurnIndex(alice, bob);

        Assert.assertFalse(alice.playCard(new MauMauCard(CardColor.CLUBS, CardType.FIVE)));
        this.updatePlayerTurnIndex(alice, bob);

        Assert.assertFalse(bob.playCard(new MauMauCard(CardColor.CLUBS, CardType.QUEEN)));
        this.updatePlayerTurnIndex(alice, bob);

        Assert.assertFalse(alice.playCard(new MauMauCard(CardColor.CLUBS, CardType.SIX)));
        this.updatePlayerTurnIndex(alice, bob);

        Assert.assertFalse(bob.playCard(new MauMauCard(CardColor.CLUBS, CardType.KING)));
        this.updatePlayerTurnIndex(alice, bob);

        Assert.assertTrue(alice.playCard(new MauMauCard(CardColor.CLUBS, CardType.SEVEN)));
    }

    private void updatePlayerTurnIndex(PlayerBackdoor a, PlayerBackdoor b) {
        a.increasePlayerIndex();
        b.increasePlayerIndex();
    }

    private List<Card> setupDeckSimpleGoodGame() {
        List<Card> cards = new ArrayList<>();

        //the first card on the discard pile
        cards.add(new MauMauCard(CardColor.SPADES, CardType.TWO));

        return cards;
    }
}